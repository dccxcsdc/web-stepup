<?php $koneksi = new mysqli("localhost","root","","step_up");
?>